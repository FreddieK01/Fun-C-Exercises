﻿using System;

namespace Multiplication_table
{
    class Program
    {
        static void Main(string[] args)
        {

            //Write a program in C# Sharp to display the multiplication table of a given integer
            Console.WriteLine("input your integer");
            var input = Console.ReadLine();
            //convert input from string to integer, if it fails print instructions
            try
            {
                int inputnum = Convert.ToInt32(input);
                int i;

                //go through dividing the input by every number smaller than it
                for (i = 1; i < inputnum; i++)
                {
                    Decimal answer = (inputnum / i);
                    // if the answer is a whole number, print the factor equation
                    if ((inputnum % i) == 0)
                    {
                        Console.WriteLine(answer + " X " + i + " = " + inputnum);
                    };

                }
            }
            catch
            {
                Console.WriteLine("Please input only a single integer");
            }

        }
    }
}
