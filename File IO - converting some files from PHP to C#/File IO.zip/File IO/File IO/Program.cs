﻿using System;
using System.IO;
using System.Text;

namespace File_IO
{
    class Program
    {
        static void Main(string[] args)
        {
            string textfilepath = @"C:\Users\Fredd\OneDrive\Documents\Coding\Projects\FileIO\WarehouseAutoQueuePostFunct3.sql";
            StreamWriter sw = File.CreateText(textfilepath);
            

            sw.WriteLine("Warehouse Consolidation Containers");
            sw.WriteLine("{");
                //Method to read data from file

                //set filepath
                string readfrom = @"C:\Users\Fredd\OneDrive\Documents\Coding\Projects\FileIO\WarehouseAutoQueue.sql";
                var lineCount = File.ReadAllLines(readfrom).Length;

                // Method for 
                string GetLine(string fileName, int line)
                {
                    using (var sr = new StreamReader(fileName))
                    {
                        for (int i = 1; i < line; i++)
                            sr.ReadLine();
                        return sr.ReadLine();
                    }
                }



                for (int n = 2; n < lineCount; n++)
                {

                    //Input
                    string input = GetLine(readfrom, n);
                    if (input.Contains("varchar"))
                    {


                        // Method to change Line into format to write to

                        //remove stuff at the end, starting from varchar
                        int indexofvc = input.IndexOf("varchar");
                        string substring = input.Substring(indexofvc);
                        string Line = input.Replace(substring, "");

                        // Remove backticks
                        char[] backtick = { '`' };
                        string NewLine = Line.Replace("`", "");


                        //Make all lowercase
                        string LowercaseNewLine = NewLine.ToLower();

                        //Get rid of the _'s and split into array, then back into string //
                        char myChar = ('_');
                        string[] splitArray = LowercaseNewLine.Split(myChar);
                        string stringtocap = string.Join(' ', splitArray);

                        //Capitalize first letter// 
                        //foreach (string[] words in splitArray)
                        var cappedstring = UppercaseWords(stringtocap);

                        // turn back into array//
                        char space = (' ');
                        string[] cappedarray = cappedstring.Split(space);
                        //string capstring = string.Join(' ', cappedstring);

                        //Stitch Back Together//
                        string noUSstring = string.Empty;
                        foreach (var item in cappedarray)
                        {
                            noUSstring += item;
                        }



                        string output = "public string " + noUSstring + " { get; set; }";
                        sw.WriteLine(output);
                    }
                    else if (input.Contains("int("))
                    {


                        // Method to change Line into format to write to

                        //remove stuff at the end, starting from varchar
                        int indexofint = input.IndexOf("int(");
                        string substring = input.Substring(indexofint);
                        string Line = input.Replace(substring, "");

                        // Remove backticks
                        char[] backtick = { '`' };
                        string NewLine = Line.Replace("`", "");


                        //Make all lowercase
                        string LowercaseNewLine = NewLine.ToLower();

                        //Get rid of the _'s and split into array, then back into string //
                        char myChar = ('_');
                        string[] splitArray = LowercaseNewLine.Split(myChar);
                        string stringtocap = string.Join(' ', splitArray);

                        //Capitalize first letter// 
                        //foreach (string[] words in splitArray)
                        var cappedstring = UppercaseWords(stringtocap);

                        // turn back into array//
                        char space = (' ');
                        string[] cappedarray = cappedstring.Split(space);
                        //string capstring = string.Join(' ', cappedstring);

                        //Stitch Back Together//
                        string noUSstring = string.Empty;
                        foreach (var item in cappedarray)
                        {
                            noUSstring += item;
                        }



                        string output = "public int " + noUSstring + " { get; set; }";
                         sw.WriteLine(output);
                    }

                }
                sw.WriteLine("}");
            sw.Close();
            
            
        }

        static string UppercaseWords(string value)
        {
            char[] array = value.ToCharArray();
            // Handle the first letter in the string.
            if (array.Length >= 1)
            {
                if (char.IsLower(array[0]))
                {
                    array[0] = char.ToUpper(array[0]);
                }
            }
            // Scan through the letters, checking for spaces.
            // ... Uppercase the lowercase letters following spaces.
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i - 1] == ' ')
                {
                    if (char.IsLower(array[i]))
                    {
                        array[i] = char.ToUpper(array[i]);
                    }
                }
            }
            return new string(array);
        }
    }
    

}
