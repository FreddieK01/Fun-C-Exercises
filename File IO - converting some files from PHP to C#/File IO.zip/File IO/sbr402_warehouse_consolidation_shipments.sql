CREATE TABLE `sbr402_warehouse_consolidation_shipments` (
  `SHIPMENT_ID` varchar(50) DEFAULT NULL,
  `PALLET_QTY` int(11) DEFAULT NULL,
  `PALLET_ID` varchar(50) DEFAULT NULL,
  `LENGTH` double DEFAULT NULL,
  `HEIGHT` double DEFAULT NULL,
  `DEPTH` double DEFAULT NULL,
  `WEIGHT` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;





